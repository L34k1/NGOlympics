package com.isep.tentative;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static com.isep.tentative.HelloApplication.mainStage;

public class gestEpreuveModController {

    @FXML
    private TableView<Epreuve> tableViewEpreuveMod;

    @FXML
    private TableColumn<Epreuve, Integer> gestEpreuveModIDcol;

    @FXML
    private TableColumn<Epreuve, LocalDate> gestEpreuveModDateCol;

    @FXML
    private TableColumn<Epreuve, String> gestEpreuveModLocationCol;

    @FXML
    private TableColumn<Epreuve, String> gestEpreuveModDisciplineCol;

    @FXML
    private TableColumn<Epreuve, String> gestEpreuveModNomCol;

    @FXML
    private TableColumn<Epreuve, Integer> gestEpreuveModDiscIDCol;

    @FXML
    private TableColumn<Epreuve, String> gestEpreuveModAthleteIDListCol;

    @FXML
    private Button bReturn;

    @FXML
    private Button bMod;

    @FXML
    private Button bClear;

    @FXML
    private TextField fieldNewDate;

    @FXML
    private TextField fieldNewLocation;

    @FXML
    private TextField fieldNewDiscipline;

    @FXML
    private TextField fieldNewName;

    @FXML
    private TextField fieldNewDisciplineID;

    @FXML
    private TextField fieldNewAthleteIDList;

    @FXML
    private TextField fieldIDselector;

    @FXML
    public void initialize() {
        EpreuveTableViewManager tableViewManager = new EpreuveTableViewManager();
        tableViewManager.initializeTable(tableViewEpreuveMod, gestEpreuveModIDcol, gestEpreuveModDateCol, gestEpreuveModLocationCol, gestEpreuveModDisciplineCol, gestEpreuveModNomCol, gestEpreuveModDiscIDCol, gestEpreuveModAthleteIDListCol);
    }

    @FXML
    private void onBModClick() {
        LocalDate date = LocalDate.parse(fieldNewDate.getText());
        String location = fieldNewLocation.getText();
        String discipline = fieldNewDiscipline.getText();
        String name = fieldNewName.getText();
        String disciplineID = fieldNewDisciplineID.getText();
        String athleteIDList = fieldNewAthleteIDList.getText();
        String idEpreuve = fieldIDselector.getText();

        if (idEpreuve.isEmpty() || date.isEmpty() || location.isEmpty() || discipline.isEmpty() || name.isEmpty() || disciplineID.isEmpty() || athleteIDList.isEmpty()) {
            System.out.println("Please fill all fields before modifying.");
            return;
        }

        try {
            int id = Integer.parseInt(idEpreuve);
            LocalDate newDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));

            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "root");
            String sql = "UPDATE \"Epreuve\" SET \"Date\" = ?, \"Location\" = ?, \"Discipline\" = ?, \"nom\" = ?, \"Discipline_ID\" = ?,\"Athlete_ID_List\" = ?::date WHERE id = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, newDate);
            statement.setBoolean(2, location);
            statement.setString(3, discipline);
            statement.setObject(4, name);
            statement.setObject(5, disciplineID);
            statement.setObject(6, athleteIDList);
            statement.setObject(7, id);

            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Epreuve with ID " + id + " has been updated.");
                EpreuveTableViewManager tableViewManager = new EpreuveTableViewManager();
                tableViewManager.initializeTable(tableViewEpreuveMod, gestEpreuveModIDcol, gestEpreuveModDateCol, gestEpreuveModLocationCol, gestEpreuveModDisciplineCol, gestEpreuveModNomCol, gestEpreuveModDiscIDCol, gestEpreuveModAthleteIDListCol);
            } else {
                System.out.println("No Epreuve found with ID " + id);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onBClearClick() {
        fieldNewDate.clear();
        fieldNewLocation.clear();
        fieldNewDiscipline.clear();
        fieldNewName.clear();
        fieldNewDisciplineID.clear();
        fieldNewAthleteIDList.clear();
    }

    @FXML
    private void onBReturnClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("gestEpreuve.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        mainStage.setTitle("Return");
        mainStage.setScene(scene);
    }
}