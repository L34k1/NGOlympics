package com.isep.tentative;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.io.IOException;
import java.time.LocalDate;

import static com.isep.tentative.HelloApplication.mainStage;

public class gestEpreuveController {

    @FXML
    private Button retourMainMenu;

    @FXML
    private TableView<Epreuve> tableViewEpreuve;

    @FXML
    private TableColumn<Epreuve, Integer> gestEpreuveIDcol;

    @FXML
    private TableColumn<Epreuve, LocalDate> gestEpreuveDateCol;

    @FXML
    private TableColumn<Epreuve, String> gestEpreuveLocationCol;

    @FXML
    private TableColumn<Epreuve, String> gestEpreuveDisciplineCol;

    @FXML
    private TableColumn<Epreuve, String> gestEpreuveNomCol;

    @FXML
    private TableColumn<Epreuve, Integer> gestEpreuveDiscIDCol;

    @FXML
    private TableColumn<Epreuve, String> gestEpreuveAthleteIDListCol;

    @FXML
    public void initialize() {
        EpreuveTableViewManager tableViewManager = new EpreuveTableViewManager();
        tableViewManager.initializeTable(tableViewEpreuve, gestEpreuveIDcol, gestEpreuveDateCol, gestEpreuveLocationCol, gestEpreuveDisciplineCol, gestEpreuveNomCol, gestEpreuveDiscIDCol, gestEpreuveAthleteIDListCol);
    }

    @FXML
    protected void onbRetourMainMenuButtonClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("mainmenu.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 680, 900);
        mainStage.setTitle("Hello!");
        mainStage.setScene(scene);
    }

    @FXML
    protected void onbAddEpreuveButtonClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("gestEpreuveAdd.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        mainStage.setTitle("Add Epreuve");
        mainStage.setScene(scene);
    }

    @FXML
    protected void onbModEpreuveButtonClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("gestEpreuveMod.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        mainStage.setTitle("Modify Epreuve");
        mainStage.setScene(scene);
    }

    @FXML
    protected void onbRemEpreuveButtonClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("gestEpreuveRem.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        mainStage.setTitle("Remove Epreuve");
        mainStage.setScene(scene);
    }

    @FXML
    protected void onbEpreuveAddDisButtonClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("gestEpreuveAddDis.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        mainStage.setTitle("Remove Epreuve");
        mainStage.setScene(scene);
    }
}
