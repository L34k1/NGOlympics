package com.isep.tentative;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import static com.isep.tentative.HelloApplication.mainStage;

public class gestEpreuveAddController {

    @FXML
    private TextField fieldDate;

    @FXML
    private TextField fieldLocation;

    @FXML
    private TextField fieldDiscipline;

    @FXML
    private TextField fieldName;

    @FXML
    private TextField fieldDisciplineID;

    @FXML
    private TextField fieldAthleteIDList;


    @FXML
    private Button bConfAddEpreuve;

    @FXML
    private Button bConfAddEpreuve1;

    @FXML
    private Button bConfAddEpreuve2;

    @FXML
    protected void onbConfAddEpreuveButtonClick() {

        LocalDate date = LocalDate.parse(fieldDate.getText());
        String location = fieldLocation.getText();
        String discipline = fieldDiscipline.getText();
        String name = fieldName.getText();
        String disciplineID = fieldDisciplineID.getText();
        String athleteIDList = fieldAthleteIDList.getText();

        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "root");
            String sql = "INSERT INTO \"Epreuve\" (\"Date\", \"Location\", \"Discipline\", \"nom\", \"Discipline_ID\",\"Athlete_ID_List\") VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, date);
            statement.setBoolean(2, location);
            statement.setString(3, discipline);
            statement.setObject(4, name);
            statement.setObject(5, disciplineID);
            statement.setObject(6, athleteIDList);// Use setObject to set LocalDate
            statement.executeUpdate();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exception
        }
    }

    @FXML
    protected void onbConfAddEpreuve1ButtonClick() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("gestEpreuve.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 680, 900);
        mainStage.setTitle("Hello!");
        mainStage.setScene(scene);
    }

    @FXML
    protected void onbConfAddEpreuve2ButtonClick() {
        // Clear all text fields
        fieldDate.clear();
        fieldLocation.clear();
        fieldDiscipline.clear();
        fieldName.clear();
        fieldDisciplineID.clear();
        fieldAthleteIDList.clear();
    }
}