import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class ResultTableViewManager {

    public void initializeTable(TableView<Resultat> tableView,
                                TableColumn<Resultat, Integer> idCol,
                                TableColumn<Resultat, String> medailleCol,
                                TableColumn<Resultat, Boolean> validationCol) {
        // Set up cell value factories for table columns
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        medailleCol.setCellValueFactory(new PropertyValueFactory<>("medaille")); // Adjust property name if necessary
        validationCol.setCellValueFactory(new PropertyValueFactory<>("validation"));

        // Add columns to the table
        tableView.getColumns().add(idCol);
        tableView.getColumns().add(medailleCol);
        tableView.getColumns().add(validationCol);

        // Load data into the table
        loadData(tableView);
    }

    // Method to load data into the table
    private void loadData(TableView<Resultat> tableView) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "root");
            String sql = "SELECT * FROM \"Resultat\"";
            PreparedStatement statement = conn.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            // Clear existing data in the table
            tableView.getItems().clear();

            // Populate table with data from the result set
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("Nom");
                boolean gender = rs.getBoolean("Sexe");
                String country = rs.getString("Pays");
                LocalDate birthdate = rs.getDate("Date de naissance").toLocalDate();

                Resultat resultat = new Resultat(id, name, gender, country, birthdate);
                tableView.getItems().add(resultat);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}