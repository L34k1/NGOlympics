package com.example.ngjofinal;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaPostgreSql {

    public static void writeToDatabase(String IDUtil) {

        String url = "jdbc:postgresql://localhost:5432/local";
        String user = "postgre";
        String password = "401131";

        String ID = IDUtil;

        String selectQuery = "SELECT COUNT(*) FROM Athlète WHERE ID = ?";
        String deleteQuery = "DELETE FROM Athlète WHERE ID = ?";

        try (Connection con = DriverManager.getConnection(url, user, password);
             PreparedStatement selectPst = con.prepareStatement(selectQuery)) {

            // test id
            selectPst.setString(1, ID);
            ResultSet rs = selectPst.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                // Slurp slurp a plus athlete
                try (PreparedStatement deletePst = con.prepareStatement(deleteQuery)) {
                    deletePst.setString(1, ID);
                    deletePst.executeUpdate();
                    System.out.println("YEEEEEEEE");
                }
            } else {
                // Pas trouvé l'id :'(
                throw new SQLException("Nuh uh");
            }

        } catch (SQLException ex) {
            Logger lgr = Logger.getLogger(JavaPostgreSql.class.getName());
            lgr.log(Level.SEVERE, ex.getMessage(), ex);
        }
    }
}