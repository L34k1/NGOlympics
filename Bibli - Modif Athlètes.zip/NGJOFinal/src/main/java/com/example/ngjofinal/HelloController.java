package com.example.ngjofinal;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    private Button submitButton;
    @FXML
    private TextField id;

    //recup la data des différents inputs

    public void getData(ActionEvent actionEvent) {
        System.out.println(id.getText());


        JavaPostgreSql.writeToDatabase(id.getText());
    }
}

