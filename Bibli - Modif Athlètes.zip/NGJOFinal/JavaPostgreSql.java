package com.example.ngjofinal;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaPostgreSql {

    public static void writeToDatabase(String IDUtil, String NomUtil, String SexeUtil, String PaysUtil, String DateUtil) {

        String url = "jdbc:postgresql://localhost:5432/local";
        String user = "postgre";
        String password = "401131";

        String ID = IDUtil;
        String Nom = NomUtil;
        String Sexe = SexeUtil;
        String Pays = PaysUtil;
        String Date_De_Naissance = DateUtil;

        String selectQuery = "SELECT COUNT(*) FROM Athlète WHERE ID = ?";
        String updateQuery = "UPDATE Athlète SET Nom = ?, Sexe = ?, Pays = ?, Date_De_Naissance = ? WHERE ID = ?";
        String insertQuery = "INSERT INTO Athlète(ID, Nom, Sexe, Pays, Date_De_Naissance) VALUES(?, ?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(url, user, password);
             PreparedStatement selectPst = con.prepareStatement(selectQuery)) {

            // test si existe
            selectPst.setString(1, ID);
            ResultSet rs = selectPst.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                // ID existe, modif:
                try (PreparedStatement updatePst = con.prepareStatement(updateQuery)) {

                    updatePst.setString(1, ID);
                    updatePst.setString(2, Nom);
                    updatePst.setString(3, Sexe);
                    updatePst.setString(4, Pays);
                    updatePst.setString(5, Date_De_Naissance);

                    updatePst.executeUpdate();
                    System.out.println("Modifié avec succès");
                }
            } else {
                // ID existe pas, sqlexcept
                throw new SQLException("Nuh uh");
            }

        } catch (SQLException ex) {
            Logger lgr = Logger.getLogger(JavaPostgreSql.class.getName());
            lgr.log(Level.SEVERE, ex.getMessage(), ex);
        }
    }
}