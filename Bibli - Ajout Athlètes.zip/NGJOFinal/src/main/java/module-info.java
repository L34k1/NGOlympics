module com.example.ngjofinal {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.ngjofinal to javafx.fxml;
    exports com.example.ngjofinal;
}