package com.example.ngjofinal;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    private Button submitButton;
    @FXML
    private TextField id;
    @FXML
    private TextField name;
    @FXML
    private TextField sexe;
    @FXML
    private TextField pays;
    @FXML
    private TextField date;

    //recup la data des différents inputs

    public void getData(ActionEvent actionEvent) {
        System.out.println(id.getText());
        System.out.println(name.getText());
        System.out.println(sexe.getText());
        System.out.println(pays.getText());
        System.out.println(date.getText());

        JavaPostgreSql.writeToDatabase(id.getText(), name.getText(), sexe.getText(), pays.getText(), date.getText());
    }
}

