package com.example.ngjofinal;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaPostgreSql {

    public static void writeToDatabase(String IDUtil, String NomUtil, String SexeUtil, String PaysUtil, String DateUtil) {

        String url = "jdbc:postgresql://localhost:5432/local";
        String user = "postgre";
        String password = "401131";

        String ID = IDUtil;
        String Nom = NomUtil;
        String Sexe = SexeUtil;
        String Pays = PaysUtil;
        String Date_De_Naissance = DateUtil;


        // query
        String query = "INSERT INTO Athlète(ID, Nom, Sexe, Pays, Date_De_Naissance) VALUES(?, ?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(url, user, password);
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, ID);
            pst.setString(2, Nom);
            pst.setString(3, Sexe);
            pst.setString(4, Pays);
            pst.setString(5, Date_De_Naissance);
            pst.executeUpdate();
            System.out.println("Sucessfully created.");

        } catch (SQLException ex) {

            Logger lgr = Logger.getLogger(JavaPostgreSql.class.getName());
            lgr.log(Level.SEVERE, ex.getMessage(), ex);
        }

    }
}
