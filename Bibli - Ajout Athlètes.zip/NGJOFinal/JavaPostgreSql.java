package com.example.ngjofinal;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaPostgreSql {

    public static void writeToDatabase(String IDUtil, String NomUtil, String SexeUtil, String PaysUtil, String DateUtil) {

        String url = "jdbc:postgresql://localhost:5432/local";
        String user = "postgre";
        String password = "401131";

        String ID = IDUtil;
        String Nom = NomUtil;
        String Sexe = SexeUtil;
        String Pays = PaysUtil;
        String Date_De_Naissance = DateUtil;

        String selectQuery = "SELECT COUNT(*) FROM Athlète WHERE ID = ?";
        String insertQuery = "INSERT INTO Athlète(ID, Nom, Sexe, Pays, Date_De_Naissance) VALUES(?, ?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(url, user, password);
             PreparedStatement selectPst = con.prepareStatement(selectQuery)) {

            // Check si il existe
            selectPst.setString(1, ID);
            ResultSet rs = selectPst.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                // Existe deja
                throw new SQLException("ID existe déjà dans la bdd");
            } else {
                // ID does not exist, insert a new record
                try (PreparedStatement insertPst = con.prepareStatement(insertQuery)) {
                    insertPst.setString(1, ID);
                    insertPst.setString(2, Nom);
                    insertPst.setString(3, Sexe);
                    insertPst.setString(4, Pays);
                    insertPst.setString(5, Date_De_Naissance);
                    insertPst.executeUpdate();
                    System.out.println("Succ sex !");
                }
            }

        } catch (SQLException ex) {
            Logger lgr = Logger.getLogger(JavaPostgreSql.class.getName());
            lgr.log(Level.SEVERE, ex.getMessage(), ex);
        }
    }
}
